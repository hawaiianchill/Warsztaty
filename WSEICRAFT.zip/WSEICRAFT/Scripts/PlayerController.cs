using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 10f;

    private Rigidbody2D rb;
    private bool canJump = false;

    //private JumpSound jumpSound; // Dodane do obs�ugi d�wi�ku

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
       // jumpSound = GetComponent<JumpSound>(); // Pobranie komponentu d�wi�ku
    }

    void Update()
    {
        // Ruch poziomy
        float move = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(move * moveSpeed, rb.velocity.y);

        // Skok
        if (Input.GetKeyDown(KeyCode.Space) && canJump)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            canJump = false; // Po skoku blokujemy mo�liwo�� kolejnego

           // if (jumpSound != null) // Odtwarzanie d�wi�ku skoku
           // {
           //   jumpSound.PlayJumpSound();
            //}
        }
    }

    // Wykrywanie kolizji - reset skoku po kontakcie z czymkolwiek
    void OnCollisionEnter2D(Collision2D collision)
    {
        canJump = true;
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        canJump = false;
    }
}
